curl -XDELETE "http://localhost:9200/2017-11-22-fake"
curl -XDELETE "http://localhost:9200/2017-11-23-fake"
