curl -XPUT 'http://localhost:9200/_xpack/license' -H "Content-Type: application/json" -d @elastic_license.json
