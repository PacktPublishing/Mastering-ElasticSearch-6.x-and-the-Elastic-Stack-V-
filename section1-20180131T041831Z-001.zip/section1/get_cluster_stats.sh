curl -XGET 'localhost:9200/_cluster/stats?human&pretty&pretty'


