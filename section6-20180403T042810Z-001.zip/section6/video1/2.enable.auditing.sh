echo "xpack.security.audit.enabled: true" >> /etc/elasticsearch/elasticsearch.yml
