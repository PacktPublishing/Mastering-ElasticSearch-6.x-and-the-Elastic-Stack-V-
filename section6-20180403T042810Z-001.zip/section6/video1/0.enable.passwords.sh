/usr/share/elasticsearch/bin/x-pack/setup-passwords
