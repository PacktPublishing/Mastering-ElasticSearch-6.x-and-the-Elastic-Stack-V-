curl http://localhost:5000/api/users
