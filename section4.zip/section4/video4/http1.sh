curl -XPOST http://localhost:1181 -d "This is a message."
