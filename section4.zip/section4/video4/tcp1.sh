telnet localhost 12345
