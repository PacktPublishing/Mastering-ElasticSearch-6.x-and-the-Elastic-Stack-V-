curl -XDELETE "http://localhost:9200/cars?pretty"
curl -XDELETE "http://localhost:9200/new_cars?pretty"
