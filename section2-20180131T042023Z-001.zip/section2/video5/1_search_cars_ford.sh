curl -XGET 'localhost:9200/cars/_search?q=make:ford&pretty'

