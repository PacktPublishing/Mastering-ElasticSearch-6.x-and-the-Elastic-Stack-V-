curl -XGET 'localhost:9200/carsforsale,cars/_search?q=make:ford&pretty'

