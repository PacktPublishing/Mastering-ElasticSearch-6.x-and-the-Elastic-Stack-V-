
curl -XPOST 'http://localhost:9200/carsforsale/car?pretty' -H 'Content-Type: application/json' -d'
{
    "user" : "fauie", "post_date" : "2009-11-15T14:12:12", "make" : "Nissan", "model" : "Sentra"
}
'

