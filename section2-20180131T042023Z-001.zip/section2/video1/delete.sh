curl -XDELETE 'localhost:9200/carsforsale/car/1?pretty' 
